
sudo sh /home/vagrant/shared/resources/apache-plume/bin/startup.sh